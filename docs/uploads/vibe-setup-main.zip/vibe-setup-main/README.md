# Vibe Coding Setup

One command prepares a new Mac for app development with Claude. When the setup is complete, Claude builds your first app with you. Everything runs on your own machine with a local Postgres database. Deployment comes later.

## Before you start

Make two free accounts before you run the script:

1. A Claude account at [claude.ai](https://claude.ai)
2. A GitHub account at [github.com/signup](https://github.com/signup)

## Run it

Open the Terminal app (press Cmd+Space, type "Terminal", press Enter). Paste this command and press Enter:

```bash
curl -fsSL https://raw.githubusercontent.com/ericskiff/vibe-setup/main/setup.sh | bash
```

The script runs almost fully automatically. It asks for your Mac password when the system needs it. It opens the browser for the GitHub login. It possibly asks for one click in Postgres.app. That is all. You can run the script again at any time. The script does not install a tool that is already installed.

## What it installs

The bootstrap phase installs the Apple Xcode Command Line Tools (compilers and Git), Homebrew (the Mac package manager), and gum (the interface the script itself uses). The guided steps then install Git and the build libraries for Ruby, mise with the latest Node.js LTS and Ruby, Postgres.app for a local database, the GitHub CLI with a browser login, and Claude Code together with the Claude desktop app. The script also configures your git identity to match your GitHub account, sets `main` as the default branch, and creates `~/Documents/src` as your projects folder.

## The handoff

The final step writes instructions for Claude to `~/Documents/src/FIRST_APP_HANDOFF.md` and copies them to your clipboard. You open Claude Code:

```bash
cd ~/Documents/src
claude --dangerously-skip-permissions
```

Then you paste. Claude verifies the environment, asks what you want to build, scaffolds a T3 app (TypeScript, Tailwind, tRPC, Prisma, App Router), connects it to your local Postgres, pushes the schema, creates a private GitHub repo, starts the dev server, and guides you through your first edit-commit-push loop.

## Development notes

The script is plain bash, compatible with the stock macOS `/bin/bash` 3.2. Check syntax with `bash -n setup.sh` and lint with `shellcheck setup.sh`. When run via `curl | bash` it reattaches stdin to `/dev/tty` so the interactive prompts work. All user-facing output follows ASD-STE100 Simplified Technical English: short sentences, active voice, one instruction per sentence, no idioms, no contractions. The curl one-liner above works once this repo is public on GitHub; until then, clone and run `bash setup.sh`.
